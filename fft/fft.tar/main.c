#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI	3.141592

struct twinddle_factor
{
	double real;
	double imag;
};

void tf_print(struct twinddle_factor *tf, int size);

struct twinddle_factor *FFT_Calc(struct twinddle_factor *result, struct twinddle_factor *input, const int size, int inverse)
{
  int i = 0;
	double degree = 2*PI/ size*inverse;
	struct twinddle_factor *t = NULL;
  
  t = (struct twinddle_factor*)malloc(sizeof(struct twinddle_factor) * size);

  for (i = 0; i < size / 2; i++) {
    t[i].real = input[i].real + input[i + size / 2].real;
		t[i].imag = input[i].imag + input[i + size / 2].imag;
  }

	for (i = 0; i < size / 2; i++) {
		t[i + size / 2].real = (input[i].real + input[i + size / 2].real)*cos(degree*(i+size/2)) + (input[i].imag - input[i + size / 2].imag)*sin(degree*i);
		t[i + size / 2].imag = (input[i + size / 2].real - input[i].real)*sin(degree*i) + (input[i].imag + input[i + size / 2].imag)*cos(degree*(i+size/2));
    
	}
  
  /* printf("%lf \n",cos(degree*4*(1))); */

	return t;
}
void Main_FFT(int size)
{

}

struct twinddle_factor *tf_init(int *array, int size)
{
  int i = 0;

  struct twinddle_factor *tf = NULL;

  if (size < 1)
    return NULL;

  tf = (struct twinddle_factor*)malloc(sizeof(struct twinddle_factor) * size);

  for (i = 0; i < size; i++) {
    tf[i].real = array[i];
    tf[i].imag = 0;
  }
  
  return tf;
}

void tf_print(struct twinddle_factor *tf, int size)
{
  int i = 0;

  for (i = 0; i < size; i++) {
    printf("%p real : %lf / imag : %lf \n", &tf[i], tf[i].real, tf[i].imag);
  }
 
}

int main(int argc, const char *argv[])
{
  int size = 8;
  /* int array[] = {1, 2, 3, 4}; */
  int array[] = {1, 2, 3, 4, 5, 6, 7, 8};
  struct twinddle_factor *tf = NULL;
  struct twinddle_factor *result = NULL;

  tf = tf_init(array, size);

  tf_print(tf, size);

  printf("===== \n\n");
  tf = FFT_Calc(result, tf, size, 1);
  tf_print(tf, size);
  
  return 0;
}
